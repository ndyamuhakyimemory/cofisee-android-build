// Secure preload reserved for future native integrations.
