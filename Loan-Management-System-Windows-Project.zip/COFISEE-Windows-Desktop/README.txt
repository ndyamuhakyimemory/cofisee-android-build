LOAN MANAGEMENT SYSTEM — WINDOWS DESKTOP EDITION

TARGET
- Windows 10 and Windows 11, 64-bit (x64)
- Installer: Loan-Management-System-Setup-1.0.0-x64.exe

BUILD FROM YOUR ANDROID PHONE USING GITHUB ACTIONS
1. Upload the complete COFISEE-Windows-Desktop folder contents to your GitHub repository, preserving the folder structure.
2. Upload .github/workflows/build-windows.yml to the repository's .github/workflows/ folder.
3. Open the repository's Actions tab.
4. Select "Build Loan Management System Windows Installer" and tap "Run workflow".
5. When it succeeds, open the run and download the artifact "Loan-Management-System-Windows-Installer".
6. Extract the downloaded artifact ZIP. It contains the Windows .exe installer.
7. Transfer the .exe to a Windows 10/11 64-bit laptop and run it.

DEVELOPER & SUPPORT DETAILS INCLUDED IN THE APP
Developer: Ndyamuhakyi Memory
Phone: 0760158082 / 0745681487
Email: ndyamuhakyimemory5@gmail.com

NOTES
- This is a Windows desktop wrapper around the supplied COFISEE HTML application.
- Existing browser/Android app records are not automatically copied into this desktop app. Export a backup from the source system and import it into the desktop app if the source application supports that backup format. Keep the original backup safely.
- Desktop app data is stored in the Windows user's Electron application data folder and is separate from Chrome and Android WebView storage.
- Windows SmartScreen may show an unknown-publisher warning because this installer is not code-signed. Only install the file you built from your own repository.
- This workflow builds a 64-bit Windows installer. It is intended for current Windows 10/11 64-bit PCs, not 32-bit Windows.
- Printing uses the Windows print dialog and printers installed in Windows. Direct Bluetooth/ESC-POS printer control is not added by this wrapper.
