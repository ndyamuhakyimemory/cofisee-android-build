LOAN MANAGEMENT SYSTEM — WINDOWS PROJECT

This package contains the Windows desktop application project with the updated offline HTML system.

APPLICATION
- Name: Loan Management System
- Target: Windows 10/11, 64-bit (x64)
- Offline records: stored locally by the HTML application in the Electron app profile.
- Supabase: not required by this offline HTML build.
- Internet: not required for ordinary local record entry and use.

GITHUB ACTIONS BUILD
1. Upload this ZIP to the ROOT of your GitHub repository. Keep the filename exactly:
   Loan-Management-System-Windows-Project.zip
2. Create a separate workflow file in the repository at:
   .github/workflows/build-windows.yml
   (GitHub only detects workflow files in this repository path; the copy inside this ZIP is just a project reference.)
3. Use the workflow YAML previously supplied for this project, which extracts the ZIP, finds package.json, runs npm install and npm run dist, then uploads the EXE artifact.
4. In GitHub, open Actions, select the Windows installer workflow, choose Run workflow, and wait for a successful run.
5. Download the artifact named Loan-Management-System-Windows-Installer and extract the setup EXE.

NOTES
- This ZIP is the source project, not the finished EXE installer. GitHub Actions builds the installer.
- The app is configured for Windows x64; it is not a 32-bit Windows build.
- Back up records before replacing an older installation. Data in the old browser/HTML version may not automatically appear in the Windows app. Use the app's backup/restore or import/export features where available.
- Local activation is a basic barrier, not hardware-bound security. Clearing app data may reset activation.
