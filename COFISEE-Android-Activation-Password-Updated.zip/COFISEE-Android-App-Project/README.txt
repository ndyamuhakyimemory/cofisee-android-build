COFISEE MICROFINANCE — ANDROID APP PROJECT
==========================================

This is an Android Studio project containing the exact HTML file you uploaded,
packaged as an offline Android WebView application.

APP DETAILS
- App name: COFISEE Microfinance
- Package: com.cofisee.microfinance
- Version: 1.0.0
- Minimum Android: Android 6.0 (API 23)
- Offline HTML asset: app/src/main/assets/index.html
- Local browser storage is enabled inside the app.
- File chooser support is enabled for importing backups/files.
- The app uses Android's WebView print support when the HTML requests printing.

HOW TO BUILD THE APK
1. Install Android Studio on a Windows computer.
2. Extract this ZIP.
3. In Android Studio choose Open, then select the extracted
   COFISEE-Android-App-Project folder.
4. Allow Android Studio to install the Android Gradle plugin/SDK if prompted.
5. Wait for Gradle Sync to finish.
6. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
7. The debug APK will be created at:
   app/build/outputs/apk/debug/app-debug.apk
8. Copy the APK to your Android phone and install it. If Android asks,
   allow installation from that file manager/browser.

IMPORTANT DATA NOTE
The HTML file you uploaded is the application program and contains no
embedded snapshot of the Chrome browser's localStorage records. Android apps
have separate private storage; the app cannot automatically read Chrome's
existing COFISEE records. Before switching, open COFISEE in the browser and
use Settings > Data & Sharing > Download JSON backup (or Download COFISEE
with all records). Then install the APK and import the backup through the
Settings import/restore controls. Keep the original HTML and backup unchanged
until you verify the records in the Android app.

PRINTER NOTE
The HTML print workflow opens the Android/WebView print path supported by the
device. This wrapper does not implement a native Bluetooth ESC/POS driver.
For some 58mm Bluetooth thermal printers, pair the printer and use its
manufacturer/compatible Android print-service app.

BUILD LIMITATION
This workspace does not include Android SDK/Gradle build tools, so it cannot
produce or sign the APK here. This ZIP is the complete Android Studio source
project to build the APK. It is not itself an APK.


SECURITY NOTES (OFFLINE BUILD)
- First opening on each fresh app installation/device storage asks you to create a master password and a separate Settings administrator password.
- Protected modules require the master password; Settings & Backup requires the administrator password.
- Password changes, business settings changes, exports and backups require administrator authorization.
- Android screenshots/recent-app previews are blocked; WebView remote debugging and cross-file URL access are disabled.
- App data remains local on the device. No Supabase or cloud login is used.
- IMPORTANT: This is local password protection, not encrypted database storage. A person with root/developer access to the device or app files may still extract or alter local records. Back up records securely and protect the device with its Android screen lock.
- Android system backup is disabled for this app to reduce unintended copying of local financial records.
