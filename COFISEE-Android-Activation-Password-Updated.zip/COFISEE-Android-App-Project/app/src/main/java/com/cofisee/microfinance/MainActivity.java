package com.cofisee.microfinance;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.webkit.JsPromptResult;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 4102;
    private static final String ACTIVATION_PREFS = "cofisee_device_activation";
    private static final String ACTIVATED_KEY = "activated_once";
    private static final String ACTIVATION_PASSWORD = "Rwigamba@12244";

    public class AndroidActivationBridge {
        @JavascriptInterface
        public boolean isActivated() {
            return getSharedPreferences(ACTIVATION_PREFS, MODE_PRIVATE)
                    .getBoolean(ACTIVATED_KEY, false);
        }
    }

    private void loadAppAfterActivation() {
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void requireOneTimeActivation() {
        SharedPreferences prefs = getSharedPreferences(ACTIVATION_PREFS, MODE_PRIVATE);
        if (prefs.getBoolean(ACTIVATED_KEY, false)) {
            loadAppAfterActivation();
            return;
        }
        final EditText password = new EditText(this);
        password.setSingleLine(true);
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        password.setHint("Enter activation password");
        password.setPadding(36, 24, 36, 24);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28, 8, 28, 4);
        TextView message = new TextView(this);
        message.setText("This device must be activated once before opening Loan Management System.");
        layout.addView(message);
        layout.addView(password, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("One-time device activation")
                .setView(layout)
                .setCancelable(false)
                .setPositiveButton("Activate", null)
                .create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (ACTIVATION_PASSWORD.equals(password.getText().toString())) {
                prefs.edit().putBoolean(ACTIVATED_KEY, true).apply();
                dialog.dismiss();
                loadAppAfterActivation();
            } else {
                password.setError("Incorrect activation password");
                password.setText("");
            }
        }));
        dialog.show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                             WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Prevent screenshots and sensitive app previews in the Android recent-apps screen.
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        // This application is fully offline and does not need WebView remote debugging.
        WebView.setWebContentsDebuggingEnabled(false);

        webView = new WebView(this);
        webView.setBackgroundColor(0xFFF4F8F5);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true); // Required to load the bundled offline HTML asset.
        settings.setAllowContentAccess(true); // Required for user-selected backup/import files.
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                // Keep the offline COFISEE app inside its own WebView.
                return !"file".equalsIgnoreCase(uri.getScheme());
            }
        });

        webView.addJavascriptInterface(new AndroidActivationBridge(), "AndroidActivation");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsPrompt(WebView view, String url, String message,
                    String defaultValue, JsPromptResult result) {
                final EditText input = new EditText(MainActivity.this);
                input.setSingleLine(true);
                input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                input.setText(defaultValue == null ? "" : defaultValue);
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("COFISEE Security")
                    .setMessage(message)
                    .setView(input)
                    .setCancelable(false)
                    .setPositiveButton("OK", (d, w) -> result.confirm(input.getText().toString()))
                    .setNegativeButton("Cancel", (d, w) -> result.cancel())
                    .show();
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = params.createIntent();
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        setContentView(webView);
        requireOneTimeActivation();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
            .setTitle("COFISEE Microfinance")
            .setMessage("Close COFISEE?")
            .setNegativeButton("Stay", (d, w) -> d.dismiss())
            .setPositiveButton("Close", (d, w) -> finish())
            .show();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
